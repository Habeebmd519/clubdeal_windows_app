import 'package:audioplayers/audioplayers.dart';

class AlertSoundService {
  AlertSoundService({AudioPlayer? player}) : _player = player ?? AudioPlayer();
  final AudioPlayer _player;
  bool _enabled = true;
  bool get enabled => _enabled;
  void setEnabled(bool value) => _enabled = value;

  Future<void> playNewOrder() async {
    if (!_enabled) return;
    await _player.stop();
    await _player.play(AssetSource('sound/alert.mp3'));
  }

  Future<void> dispose() => _player.dispose();
}
