// IMPORTANT:
// Replace this file with the firebase_options.dart generated for your
// existing Club Deal Firebase project using `flutterfire configure`.
// The file is intentionally kept as a small placeholder in this desktop
// starter so the desktop lib can be separated from the Android project.

import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    throw UnsupportedError(
      'Run flutterfire configure for the Windows desktop project.',
    );
  }
}
